useing UnityEngine;
useing UnityEngine\user\Player;

namespace kartRush.Hack{

    public UnityEngine = ".";

    public class KartRush{

        Log();
        
        public move(Player $user, bool $bool = true){
            $x = $user->x;
            $y = $use->y;
            $z = $user->z;
            if ($bool == false){
                $pos = $x / $y / $z;//결과: 0
                $user->move($pos);
            }else{
                $pos = $y +3;
                $user->move($pos);
            }
        }
    }
    public speed(Player $user){
        if (! ismove(false)){
        }else{
            $user->move($user->getSpeed() * 5);
        }
    }

    public Player(){
        return getName();
    }

    public Log(){
        UnityEngine::Log(Player."핵 사용중 ㅅㄱ 뚫림!");//유니티 프로그램 -> 콘솔 전송!
    }

    public ismove(bool $bool){
        if ($bool == false){
            return $bool;
        }else{
            return true;
        }
    }
    public kick(){
        user.kick("올킥!");
    }

    public function teleport(Player $p){
        $x = $p->x;
        $y =$p->y;
        $z = $p->z;
        $xyz = $x.":".$y.":".$z;
        $p->move($xyz);
    }
}