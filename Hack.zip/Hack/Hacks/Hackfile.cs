useing UnityEngine;

namespace kartRush.Hack{

    public class Hackfile{

        public void Fly(speed = 1.5){
            p = Player.GetPlayer();
            p.move(false);
            p.Flying(speed);
            pk = new UnityEngine;
            pk.move(false);
            pk.Fly(true);
            pk.Flying(speed);
        }
    }
}