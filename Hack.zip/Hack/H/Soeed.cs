useing UnityEngine\User;
useing Hack.KartRush;

namespace kartRush.Hack{
    
    public class Speed{

        public setSpeed(user $p, int $speed){
            $x = $p->x;
            $y = $p->y;
            $z = $p->z;
            kartRush.move($p, true);
            kartRush::speed($p);        
        }
    }
}